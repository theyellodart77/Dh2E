# DISCLAIMER

I know nothing about coding, I literally failed a coding class in college, but wanted to dink around and see if I could adapt the code made by the original publisher for Wrath & Glory to DH2E with the appropriate skill names.  If somethings broken Im sure its my fault and I am sure I dont know how to fix it.  Youd have better luck reaching out to the original publisher.  I have left all of his stuff below.

Cherb The Fat Bard




# 40k - Wrath & Glory - character sheet

## A brand new Symbiote to play Wrath & Glory !

### How to use it ? 

- Wrath dice :
You can click on the wrath checkbox if you want to use a dice wrath. The first dice in the track is used as  the wrath dice.
- The skills Traits and Attributes : 
I've left the inputs for Attributes, Traits and Skills completely free to use. I don't know enough of Wrath&Glory to know how to use them correctly. The skill buttons use the total value to throw the right amount of d6.
- The Arsenal :
to create a new weapon you must follow this pattern : 
##### "name";"range";"dice and modifier";"armour penetration";"salvo";"description"
- Name : gor for what you want, really
- Range : it must be either "melee" or 3 numbers with a space between them ex : "12 24 36"
- Dices : you must put in this order the number of d6 and the modifier right after ex : "4d6+6"
- AP : put a value between 1-9 or put "-"
- Salvo : same as AP
- Description : you can do as you want here.
Exemple : Chainsword;melee;4d6+9;-;-;Brutal, Parade


### Context

- Why this symbiote ?
I'm currently learning this new rpg paper and I decided to test symbiote by developping a character sheet for this system.

- Who am I ? 
I'm a junior dev and i also did this project to work on some language that i don't usually use.

### To do

- Maybe upgrade wargear, abilities and description tabs to have a similar behaviour as the weapon tab.
        -> It means allow for  the possibility to inject new html attribute and hide the text-area.

- Learn more of the game to be able to adresse other things like psychic powers ? I'll know when i'll play.

- Automatically fill the total of the each skills 

- Catch my errors to prevent bugs 

### Inspirations

Thanks to PanoramicPanda and his w40k diceRoller [a link](https://mod.io/g/talespire/m/warhammer-40k-dice-roller)
It helped me deal with the log messages after rolling the dice.
I also took inspiration from the generic character sheet.

Thanks for reading this ! Don't be to harsh, i did this in 3 days :P
Feel free to give some feedback. It's appreciated !